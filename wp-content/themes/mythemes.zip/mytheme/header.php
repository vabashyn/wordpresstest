<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title>HTML Document</title>
    <link rel="stylesheet" href="<?php bloginfo('stylesheet_url');?>">
</head>
<body>
<div class="wrapper">

<h1>Header</h1>